************
Broadcasting
************

.. seealso:: :class:`numpy.broadcast`

.. automodule:: numpy.doc.broadcasting
